This directory needs to include the following files:

annotations-1.3.9-cw.jar
ant.jar
jsr305-1.3.9.jar

JeremyC 20-11-2018
