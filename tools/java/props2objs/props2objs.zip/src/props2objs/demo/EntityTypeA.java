package props2objs.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import edu.umd.cs.findbugs.annotations.Nullable;

public class EntityTypeA implements Entity<EntityTypeA>, EntityFactory<EntityTypeA> {
	// The data members of this particular entity type.
	private final String m_name;
    private final String m_attr1;
    private final String m_attr2;
	
	private static class TypeAProps extends Props {
	    private TypeAProps(Properties prop) {
            super(prop, "entity", "typeA");
        }
		
		private EntityTypeA getEntity(String name) {
            String attr1 = getProperty(name + ".attr1");
            String attr2 = getProperty(name + ".attr2");
            return new EntityTypeA(name, attr1, attr2);
        }
	}
	    
	public EntityTypeA(String name, String attr1, String attr2) {
		m_name = name;
        m_attr1 = attr1;
        m_attr2 = attr2;
    }
	
	public EntityTypeA() {
		m_name = "";
        m_attr1 = "";
        m_attr2 = "";
    }
	
	public String action1() {
		return String.format("EntityTypeA: action1: name=%s [attr1=%s, attr2=%s]", 
				m_name, m_attr1, m_attr2);
	}
	
	public String action2() {
		return String.format("EntityTypeA: action2: name=%s [attr1=%s, attr2=%s]", 
				m_name, m_attr1, m_attr2);
	}
	
	public List<EntityTypeA> getEntities() {
        Properties p = Config.getProperties();
		TypeAProps props = new TypeAProps(p);
        List<EntityTypeA> entities = new ArrayList<EntityTypeA>();
        for (String n : props.getNames()) {
            EntityTypeA e = props.getEntity(n);
            if (e != null)
                entities.add(e);
        }
        return entities;
	}
	
	public EntityFactory<EntityTypeA> getFactory() {
        return getFactory(null);
    }
	 
	public static EntityFactory<EntityTypeA> getFactory(@Nullable Boolean ignore) {
		return new EntityTypeA();
	}
}
