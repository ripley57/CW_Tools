package props2objs.demo;

public interface Filter<T> 
{
    public boolean accept(T arg) throws Exception;
}