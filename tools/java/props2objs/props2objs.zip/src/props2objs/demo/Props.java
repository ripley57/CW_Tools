package props2objs.demo;

import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

public abstract class Props {
	private final FilteredProps m_props; 
	private final String m_prefix;
	private final String m_type;
	
	protected Props(Properties props, String prefix, String type) {
		this.m_prefix = prefix;
		this.m_type = type;
		
		this.m_props = new FilteredProps(props, new PatternMatcher(this.m_prefix + "." + m_type + ".*"));
    }
	
	protected Props(Properties props, String type) {
		this(props, type, "entity.");
    }
	
	public Set<String> getNames() {
        Set<String> names = new HashSet<String>();
        for (String n : m_props.getFilteredPropertyNames()) {
        	/*
        	 * Property names have the following format:
        	 * 	<prefix>.<type>.<name>.<field>=<value>
        	 * We want to extract just the <name> part.
        	 */
            String[] tokens = n.split("\\.", 3);
            if (tokens.length != 3)
                continue;
            tokens = tokens[2].split("\\.", 2);
            names.add(tokens[0]);
        }
        return names;
    }
	
	public String getProperty(String name, String defVal) throws RuntimeException {
        return m_props.getProperty(this.m_prefix + "." + this.m_type + "." + name, defVal);
    }
	
	public String getProperty(String name) throws RuntimeException {
        return getProperty(name, "");
    }
}
