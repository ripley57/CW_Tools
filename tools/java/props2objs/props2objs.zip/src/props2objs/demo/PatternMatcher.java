package props2objs.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class PatternMatcher implements Filter<String> {
	private final Pattern[] m_patterns;
	
	public PatternMatcher(String... globs) throws PatternSyntaxException {
		List<Pattern> patterns = new ArrayList<Pattern>();
		for (String g : globs) {
            try {
            	patterns.add(Pattern.compile(convertGlobToRegex(g))); 
            } catch (PatternSyntaxException pe) {
                PatternSyntaxException e = new PatternSyntaxException(pe.getDescription(), g, pe.getIndex());
                e.initCause(pe);
                throw e;
            }
        }
		m_patterns = patterns.toArray(new Pattern[patterns.size()]);
    }
	
	
	public static String convertGlobToRegex(String glob) {
        char[] chars = glob.toCharArray();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == '?')
                sb.append(".");
            else if (chars[i] == '*')
                sb.append(".*");
            else if ("\\()+^$.[]|{}".indexOf(chars[i]) > -1)
                sb.append("\\").append(chars[i]);
            else
                sb.append(chars[i]);
        }
        return sb.toString();
    }
	
	public boolean accept(String str) {
        for (Pattern p : m_patterns) {
            if (p.matcher(str).matches())
                return true;
        }
        return false;
    }
}
