package props2objs.demo;

import java.util.List;

public interface EntityFactory<T extends Entity<T>> {

    List<T> getEntities();
	
}