package props2objs.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import edu.umd.cs.findbugs.annotations.Nullable;

public class EntityTypeB implements Entity<EntityTypeB>, EntityFactory<EntityTypeB> {
	// The data members of this particular entity type.
	private final String m_name;
    private final String m_attr1;
    private final String m_attr2;
    private final String m_attr3;
    private final String m_attr4;
	
	private static class TypeBProps extends Props {
	    private TypeBProps(Properties prop) {
	    	super(prop, "entity", "typeB");
        }
	    
		private EntityTypeB getEntity(String name) {
            String attr1 = getProperty(name + ".attr1");
            String attr2 = getProperty(name + ".attr2");
            String attr3 = getProperty(name + ".attr3");
            String attr4 = getProperty(name + ".attr4");
            return new EntityTypeB(name, attr1, attr2, attr3, attr4);
        }
	}
	
	public EntityTypeB(String name, String attr1, String attr2, String attr3, String attr4) {
		m_name = name;
        m_attr1 = attr1;
        m_attr2 = attr2;
        m_attr3 = attr3;
        m_attr4 = attr4;
    }
	
	public EntityTypeB() {
		m_name = "";
        m_attr1 = "";
        m_attr2 = "";
        m_attr3 = "";
        m_attr4 = "";
    }

	public String action1() {
		return String.format("EntityTypeB: action1: name=%s [attr1=%s, attr2=%s, attr3=%s, attr4=%s]", 
				m_name, m_attr1, m_attr2, m_attr3, m_attr4);
	}
	
	public String action2() {
		return String.format("EntityTypeB: action2: name=%s [attr1=%s, attr2=%s, attr3=%s, attr4=%s]", 
				m_name, m_attr1, m_attr2, m_attr3, m_attr4);
	}
	
	public List<EntityTypeB> getEntities() {
        Properties p = Config.getProperties();
		TypeBProps props = new TypeBProps(p);
        List<EntityTypeB> entities = new ArrayList<EntityTypeB>();
        for (String n : props.getNames()) {
            EntityTypeB e = props.getEntity(n);
            if (e != null)
                entities.add(e);
        }
        return entities;
    }
	
	public EntityFactory<EntityTypeB> getFactory() {
        return getFactory(null);
    }

	public static EntityFactory<EntityTypeB> getFactory(@Nullable Boolean ignore) {
		return new EntityTypeB();
    }
}