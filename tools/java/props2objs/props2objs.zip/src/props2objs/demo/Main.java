/*
 * Description:
 * 	Program that demonstrates how the creation of different
 * 	objects types can be driven by a Java Properties file.
 * 
 * 	To run the program, pass on the command-line the single
 * 	action (method) that you want to invoke of each different 
 * 	object types, i.e. "action1" or "action2". Example:
 * 
 * 	java -cp lib/annotations-1.3.9-cw.jar;lib/ant.jar;lib/jsr305-1.3.9.jar;classes props2objs.demo.Main action1
 *  Running...
 *  Performing Action1: ...
 *  EntityTypeA: action1: name=obj2 [attr1=val1_obj2, attr2=val2_obj2]
 *  EntityTypeA: action1: name=obj1 [attr1=val1_obj1, attr2=val2_obj1]
 *  EntityTypeB: action1: name=obj3 [attr1=val1_obj3, attr2=val2_obj3, attr3=val3_obj3, attr4=val4_obj3]
 */

package props2objs.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static interface Handler {
        void runAction(PrintWriter out, String... args) throws Exception;
    }

	/*
	 * The different actions (methods) that can be invoked
	 * on any of the different object types that we create.
	 */
	public static enum Cmd {
        ACTION1(new Action1()),
        ACTION2(new Action2());
		
		private final Handler h;
		
		private Cmd(Handler h) {
            this.h = h;
        }
		
		public String cmd() {
            return name().toLowerCase();
        }
		
		public Handler getActionHandler() {
			return this.h;
		}
	};
	
	public static class Action1 implements Handler {
		public void runAction(PrintWriter out, String... args) throws Exception {
			System.out.println("Performing Action1: " + String.join(" ", args) + "...");
			for (EntityFactory<? extends Entity<?>> f : getAllEntityFactories()) {
                List<? extends Entity<?>> el = f.getEntities();
                for (Entity<?> e : el) {
                    action1(out, e);
                }
            }
		}		
	};
	
	public static class Action2 implements Handler {
	 	public void runAction(PrintWriter out, String... args) throws Exception {
			System.out.println("Performing Action2: " + String.join(" ", args) + " ...");
			for (EntityFactory<? extends Entity<?>> f : getAllEntityFactories()) {
                List<? extends Entity<?>> el = f.getEntities();
                for (Entity<?> e : el) {
                    action2(out, e);
                }
            }
		}		
	};
	
	private static List<EntityFactory<? extends Entity<?>>> getAllEntityFactories() {
		List<EntityFactory<? extends Entity<?>>> factories = new ArrayList<EntityFactory<? extends Entity<?>>>();
        factories.add(EntityTypeA.getFactory(null));
		factories.add(EntityTypeB.getFactory(null));
		return factories;
	}
	
	private static void action1(PrintWriter out, Entity<?> e) throws IOException {
        out.println(e.action1());
	}
	
	private static void action2(PrintWriter out, Entity<?> e) throws IOException {
        out.println(e.action2());
    }

	public static void main(String[] args) {
		try { 
			System.out.println("Running...");
			new Main().run(new PrintWriter(System.out, true /*autoflush*/), args);
		} catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
	}
	
	public void run(PrintWriter out, String[] args) throws Exception {
		if (args.length < 1) {
			System.err.println("ERROR: Input argument of \"action1\" or \"action2\" expected.");
			System.exit(1);
		}
		String cmdStr = args[0];
		//out.println("cmdStr=" + cmdStr);
	
		// Remove first element of args, as this is the command.
	    String[] newargs = new String[args.length-1];
        System.arraycopy(args, 1, newargs, 0, args.length-1);
        args = newargs;
		
        Cmd cmd;
        try {
            cmd = Cmd.valueOf(cmdStr.toUpperCase());
			//System.out.println("cmd=" + cmd.cmd());

        } catch (Exception e) {
			out.println("ERROR: Bad command: " + cmdStr);
            return;
        }
        cmd.getActionHandler().runAction(out, args);
	}
}
