package props2objs.demo.ant;

/*
 * https://www.developer.com/java/article.php/3630721/Introduction-to-Custom-Ant-Tasks.htm
 */

import java.util.Hashtable;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.Property;

public class AutoPropTask extends Property {
	public void execute()
		throws BuildException
	{
		Project project = getProject();
		Hashtable<String,Object> props = project.getProperties();	
		
		/*
		 *  Convert -Dbuild.args= passed on the Ant command-line into Ant project properties. 
		 */
		String args = (String)props.get("build.args");
		if (args != null) {
			int cnt = 0;
			for(String arg: args.split("\\|")) {
				String prop = "build.arg" + String.valueOf(cnt);
				project.setProperty(prop, arg);
				log(String.format("set %s=%s", prop, arg), Project.MSG_INFO);
				cnt++;
			}
		}
    }
}
