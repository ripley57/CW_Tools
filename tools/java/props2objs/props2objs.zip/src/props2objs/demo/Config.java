package props2objs.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;

public class Config {
	private static final String PROPERTIES_FILE = "./program.props";
	private static Properties PROGRAM_PROPS;
 
	static	{
		PROGRAM_PROPS = new Properties();
 		readPropertiesFile(PROGRAM_PROPS, new File(PROPERTIES_FILE));
	}
		
	public static void readPropertiesFile(final Properties outProps, File inPropsFile) {
		try {
			FileInputStream fin = new FileInputStream(inPropsFile);
            Properties props = new Properties();
            props.load(fin);
            for (Entry<?, ?> e : props.entrySet()) {
                String p = (String)e.getKey();
                String v = (String)e.getValue();
                outProps.put(p, v);
            }
		} catch (IOException ioe) {
            throw new RuntimeException("Error reading properties file: " + inPropsFile);
		}
    }
	
	public static Properties getProperties() {
		return PROGRAM_PROPS;
	}
}