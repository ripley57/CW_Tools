package props2objs.demo;

public interface Entity<T extends Entity<T>> {

    String action1();
	String action2();
	
    EntityFactory<T> getFactory();
	
}