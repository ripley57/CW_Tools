package props2objs.demo;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

public class FilteredProps {
	private final Filter<String> m_filter;
	private final Properties m_properties;
	
	public FilteredProps(final Properties props, final Filter<String> filter) {
		m_filter = filter;
		m_properties = props;
	}
	
	public Properties getProperties() throws RuntimeException {
		try {
			Properties props = new Properties();
			Set<String> names = getFilteredPropertyNames();
			for (final String p : names) {
				String val = m_properties.getProperty(p);
				if (val != null)
					props.setProperty(p, val);
			}
			return props;
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}	
    }
	
	public Set<String> getFilteredPropertyNames() throws RuntimeException {
	try {
        Set<String> propNames = new HashSet<String>();
        for (Enumeration<?> e = m_properties.propertyNames(); e.hasMoreElements();) {
            String p = (String)e.nextElement();
            if (m_filter.accept(p))
                 propNames.add(p);
        }
        return propNames;
	} catch (Exception e) {
		throw new RuntimeException(e);
    }
	}
	
	public String getProperty(String name, String defVal) throws RuntimeException {
		try {
			if (m_filter.accept(name))
				return m_properties.getProperty(name, defVal);
			return defVal;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public String getProperty(String name) throws RuntimeException {
		return getProperty(name, "");
	}
}