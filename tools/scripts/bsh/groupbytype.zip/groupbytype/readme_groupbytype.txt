groupbytype readme

This script parses the metadata XML from an export and creates reports
based on the mime types and file type groupings.

NOTE: To run this script, you need to be on a system with Cygwin installed.
      After you have unzipped groupbytype.zip, you may need to adjust the
      path to the Cygwin installation (default location C:\cygwin).

To run the script:

1. Unzip groupbytype.zip into a temporary directory containing the clearwell_export_000*.xml files. 

2. Launch a DOS prompt and cd to the temporary directory created in step 1.

3. Run the report as follows:

run_groupbytype.bat

4. You should see output similar to the following:

File report1.log contains "DocID|mimeType" sorted by mime type.
File report2.log contains "mimeType|DocID|file groups this mime type is a member of".

Breakdown by file type:
     14 Adobe Acrobat PDF
      1 All images
    534 All word processing documents
     95 Microsoft Excel, All spreadsheets
     27 Microsoft Power Point
     65 Microsoft Word, All word processing documents

Breakdown by mime type:
     65 application/msword
     14 application/pdf
     95 application/vnd.ms-excel
     27 application/vnd.ms-powerpoint
      1 image/tiff
    534 text/plain

Finished

(JeremyC 17/10/2012)
