# Description:
#	This script takes the xml files from a metadata export,
#   extracts the docid and mimetype values into a file,
#   then uses a mapping file to produce a report listing
#   the counts of file types and mime types present.
#
# Usage:
#   To run this script, you need to be in a Cygwin or 
#   Linux/UNIX shell. You also need to have the 
#   clearwell_export_0000*.xml files in the current
#   directory.
#
# Example usage:
#	sh groupbytype.sh
#
# Example output:
#
# File report1.log contains "DocID|mimeType" sorted by mime type.
# File report2.log contains "mimeType|DocID|file groups this mime type is a member of".
#
# Breakdown by file type:
#     14 Adobe Acrobat PDF
#      1 All images
#    534 All word processing documents
#     95 Microsoft Excel, All spreadsheets
#     27 Microsoft Power Point
#     65 Microsoft Word, All word processing documents
#
# Breakdown by mime type:
#     65 application/msword
#     14 application/pdf
#     95 application/vnd.ms-excel
#     27 application/vnd.ms-powerpoint
#      1 image/tiff
#    534 text/plain#
#
# JeremyC 17/10/2012

XML_FILES=$(ls -1 clearwell_export_*.xml | sort)

# Extract Doc ID and MimeType from metadata xml.
#
# We should end up with something like:
# 0.7.966.983|application/msword
# 0.7.966.988|application/msword
# 0.7.966.99|application/msword
# 0.7.966.996|application/msword
# 0.7.966.122|application/pdf
# 0.7.966.3443|application/pdf
#
# Note how we sort the results by mime type (sort -k2). 
# This is required when we use the mapping file shortly.
rm -f report1.log
cat $XML_FILES | grep 'Document DocID=' clearwell_export_0000001.xml | sed -n 's/.* DocID="\(.*\)" .* MimeType="\(.*\)".*$/\1|\2/p' | sort -t\| -k 2 -f > report1.log

# Use out mapping file to group out report by file type.
#
# Our mapping file is sorted by mime type and looks like this:
# 123|All spreadsheets
# application/msoutlook|Email (.msg file)
# application/msword|Microsoft Word, All word processing documents
# application/pdf|Adobe Acrobat PDF
# application/vnd.ms-excel.addin.macroEnabled.12|Microsoft Excel, All spreadsheets
# application/vnd.ms-excel.sheet.binary.macroEnabled.12|Microsoft Excel, All spreadsheets
#
# We should end up with something like this:
# application/msword|0.7.966.988|Microsoft Word, All word processing documents
# application/msword|0.7.966.99|Microsoft Word, All word processing documents
# application/msword|0.7.966.996|Microsoft Word, All word processing documents
# application/pdf|0.7.966.122|Adobe Acrobat PDF
# application/pdf|0.7.966.3443|Adobe Acrobat PDF
# application/pdf|0.7.966.3481|Adobe Acrobat PDF
rm -f report2.log
join -t\| -i -12 report1.log -21 mapMimeToTypeSortedByMime.log > report2.log

echo
echo "File report1.log contains \"DocID|mimeType\" sorted by mime type."
echo "File report2.log contains \"mimeType|DocID|file groups this mime type is a member of\"."

echo
echo "Breakdown by file type:"
cat report2.log | sort -t\| -k3 | cut -d\| -f3 | uniq -c

echo 
echo "Breakdown by mime type:"
cat report2.log | sort -t\| -k1 | cut -d\| -f1 | uniq -c

echo
echo "Finished"

