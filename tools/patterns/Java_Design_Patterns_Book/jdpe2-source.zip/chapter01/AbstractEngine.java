/*
 *  Java Design Pattern Essentials - Second Edition, by Tony Bevis
 *  Copyright 2012, Ability First Limited
 *
 *  This source code is provided to accompany the book and is provided AS-IS without warranty of any kind.
 *  It is intended for educational and illustrative purposes only, and may not be re-published
 *  without the express written permission of the publisher.
 */
package chapter01;

public abstract class AbstractEngine implements Engine {
    
    private int size;
    private boolean turbo;
    
    public AbstractEngine(int size, boolean turbo) {
        this.size = size;
        this.turbo = turbo;
    }
    
    public int getSize() {
        return size;
    }
    
    public boolean isTurbo() {
        return turbo;
    }
    
    public String toString() {
        return getClass().getSimpleName() +
                " (" + size + ")";
    }
    
}
