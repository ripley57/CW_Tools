/**
 * JBehave stories go in the directories below this one.
 * Stories are grouped into sub-directories, by high-level functionality.
 * Each sub-directory has a narrative.txt file, which contains a brief description
 * of the high-level functionality.
 */
package stories;