/**
* This package contains the main test runner and any other test runners you might need.
*
* JeremyC 28-07-2019:
* See "Running parallel acceptance tests within your automated build" page 332 in "BDD In Action".
* Apparently, by creating a separate test suite class (e.g. BookingAFlight.java) corresponding to 
* each JBehave .story file (e.g. booking_a_flight.story), you can use the parallel execution 
* capabilities that come with the Maven JUnit test runner Failsafe.
* HOWEVER, I don't think this is being used, because we are only getting a single txt output file,
* named after only testsuite "AcceptanceTestSuite.java":
* target/failsafe-reports/TEST-com.bddinaction.chapter8.jbehave.AcceptanceTestSuite.xml
* QUESTION: Could this be happening because of this we have in our pom.xml?:
* *TestSuite.java</include>
* ANSWER: Yes, I think so. I think we CAN get this to work (tbc) by updating our pom.xml file to
* point to each of our story-level testsuite .java files - see:
* https://mdolinin.github.io/blog/2014/01/17/thucydides-plus-jbehave-plus-maven-run-tests-in-parallel/
*  
*/
package com.bddinaction.chapter8.jbehave;
