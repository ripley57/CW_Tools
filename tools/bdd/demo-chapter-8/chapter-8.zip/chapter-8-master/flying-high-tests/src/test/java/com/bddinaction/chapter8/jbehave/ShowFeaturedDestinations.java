package com.bddinaction.chapter8.jbehave;

import net.thucydides.jbehave.ThucydidesJUnitStory;

public class ShowFeaturedDestinations extends ThucydidesJUnitStory {}
