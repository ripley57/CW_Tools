chapter-2 demo from "BDD In Action"

See my comments in flying-high-test/pom.xml


JeremyC 28-07-2019
